var searchData=
[
  ['leerimagen_23',['LeerImagen',['../classImagen.html#a3a4b1782bf010d02ded33d1ccd736be4',1,'Imagen']]],
  ['leerimagenpgm_24',['LeerImagenPGM',['../imagenES_8h.html#a7989c5e096410d5bb9ac230b53ab1304',1,'LeerImagenPGM(const char nombre[], int &amp;filas, int &amp;columnas, unsigned char buffer[]):&#160;imagenES.cpp'],['../imagenES_8cpp.html#a7989c5e096410d5bb9ac230b53ab1304',1,'LeerImagenPGM(const char nombre[], int &amp;filas, int &amp;columnas, unsigned char buffer[]):&#160;imagenES.cpp']]],
  ['leerimagenppm_25',['LeerImagenPPM',['../imagenES_8h.html#a4a6f0611d8fe9496ad0f3525e29684de',1,'LeerImagenPPM(const char nombre[], int &amp;filas, int &amp;columnas, unsigned char buffer[]):&#160;imagenES.cpp'],['../imagenES_8cpp.html#a4a6f0611d8fe9496ad0f3525e29684de',1,'LeerImagenPPM(const char nombre[], int &amp;filas, int &amp;columnas, unsigned char buffer[]):&#160;imagenES.cpp']]],
  ['leertipoimagen_26',['LeerTipoImagen',['../imagenES_8h.html#a4ba3a13a2951f968a61b3d60b06c8784',1,'LeerTipoImagen(const char nombre[], int &amp;filas, int &amp;columnas):&#160;imagenES.cpp'],['../imagenES_8cpp.html#a4ba3a13a2951f968a61b3d60b06c8784',1,'LeerTipoImagen(const char nombre[], int &amp;filas, int &amp;columnas):&#160;imagenES.cpp']]],
  ['limpiartransp_27',['LimpiarTransp',['../classImagen.html#aa3fd5e0c5d3ac1af55cbbd035bae29a1',1,'Imagen']]]
];
