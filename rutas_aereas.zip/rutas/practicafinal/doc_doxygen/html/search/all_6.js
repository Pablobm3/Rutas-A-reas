var searchData=
[
  ['imagen_15',['Imagen',['../classImagen.html',1,'Imagen'],['../classImagen.html#ab2e649aa7a105155c7bfdb846abf0528',1,'Imagen::Imagen()'],['../classImagen.html#a4b397c4a3dc0794cab351f96dc9390fd',1,'Imagen::Imagen(int f, int c)'],['../classImagen.html#a5c25efc6e460f6de605942460db48057',1,'Imagen::Imagen(const Imagen &amp;I)']]],
  ['imagenes_2ecpp_16',['imagenES.cpp',['../imagenES_8cpp.html',1,'']]],
  ['imagenes_2eh_17',['imagenES.h',['../imagenES_8h.html',1,'']]],
  ['img_5fdesconocido_18',['IMG_DESCONOCIDO',['../imagenES_8h.html#a8914f6544a484741b05c092d9e7522eda23c8d70e6eadf2d0d0ee1fd3bb293384',1,'imagenES.h']]],
  ['img_5fpgm_19',['IMG_PGM',['../imagenES_8h.html#a8914f6544a484741b05c092d9e7522eda8fbef75c1a0002dd6099c6cc1a43e441',1,'imagenES.h']]],
  ['img_5fppm_20',['IMG_PPM',['../imagenES_8h.html#a8914f6544a484741b05c092d9e7522eda1269c51434b906a7e507f5b49663bf4f',1,'imagenES.h']]],
  ['insertar_21',['Insertar',['../classAlmacen__Rutas.html#ad7825f70ab10f1c998650994385d27f7',1,'Almacen_Rutas::Insertar()'],['../classPaises.html#af8696fe195de53bf173bc40b314599f3',1,'Paises::Insertar()'],['../classRuta.html#aa510f8db2d5d0ae7e41861d2ca2108ef',1,'Ruta::Insertar()']]],
  ['iterator_22',['iterator',['../classPaises_1_1iterator.html',1,'Paises::iterator'],['../classAlmacen__Rutas_1_1iterator.html',1,'Almacen_Rutas::iterator'],['../classRuta_1_1iterator.html',1,'Ruta::iterator'],['../classAlmacen__Rutas_1_1iterator.html#a012b95e30592bcc02f34789e9d19b94a',1,'Almacen_Rutas::iterator::iterator()'],['../classPaises_1_1iterator.html#a57a185897b05cb53944a1e40952c77ff',1,'Paises::iterator::iterator()'],['../classRuta_1_1iterator.html#aa7a86388a6b3ffcf1fa4211a72832ddd',1,'Ruta::iterator::iterator()']]]
];
