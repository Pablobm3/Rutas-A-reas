var searchData=
[
  ['num_5fcols_28',['num_cols',['../classImagen.html#a91a9ab285292cd594c54c1119dd93484',1,'Imagen']]],
  ['num_5ffilas_29',['num_filas',['../classImagen.html#a4cb4faa04f5e2913965e43a6a65acfd1',1,'Imagen']]]
];
