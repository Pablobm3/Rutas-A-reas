var searchData=
[
  ['img_5fdesconocido_101',['IMG_DESCONOCIDO',['../imagenES_8h.html#a8914f6544a484741b05c092d9e7522eda23c8d70e6eadf2d0d0ee1fd3bb293384',1,'imagenES.h']]],
  ['img_5fpgm_102',['IMG_PGM',['../imagenES_8h.html#a8914f6544a484741b05c092d9e7522eda8fbef75c1a0002dd6099c6cc1a43e441',1,'imagenES.h']]],
  ['img_5fppm_103',['IMG_PPM',['../imagenES_8h.html#a8914f6544a484741b05c092d9e7522eda1269c51434b906a7e507f5b49663bf4f',1,'imagenES.h']]]
];
