var searchData=
[
  ['imagen_76',['Imagen',['../classImagen.html#ab2e649aa7a105155c7bfdb846abf0528',1,'Imagen::Imagen()'],['../classImagen.html#a4b397c4a3dc0794cab351f96dc9390fd',1,'Imagen::Imagen(int f, int c)'],['../classImagen.html#a5c25efc6e460f6de605942460db48057',1,'Imagen::Imagen(const Imagen &amp;I)']]],
  ['insertar_77',['Insertar',['../classAlmacen__Rutas.html#ad7825f70ab10f1c998650994385d27f7',1,'Almacen_Rutas::Insertar()'],['../classPaises.html#af8696fe195de53bf173bc40b314599f3',1,'Paises::Insertar()'],['../classRuta.html#aa510f8db2d5d0ae7e41861d2ca2108ef',1,'Ruta::Insertar()']]],
  ['iterator_78',['iterator',['../classAlmacen__Rutas_1_1iterator.html#a012b95e30592bcc02f34789e9d19b94a',1,'Almacen_Rutas::iterator::iterator()'],['../classPaises_1_1iterator.html#a57a185897b05cb53944a1e40952c77ff',1,'Paises::iterator::iterator()'],['../classRuta_1_1iterator.html#aa7a86388a6b3ffcf1fa4211a72832ddd',1,'Ruta::iterator::iterator()']]]
];
